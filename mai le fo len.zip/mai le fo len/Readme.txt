SVP made by RainRC

*You Should Credit Me If You Use This SVP
使用请注明出处
*You are allowed to redistribute this SVP if you credit me
重分发需要注明出处



##真的有人会来用这个吗##
##我有点不行了##